
        <?php
        Session_start();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ProjectDB";


        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
           die("Connection failed: " . $conn->connect_error);
        }




              $id = $_SESSION["ID"];


                $out = "SELECT * FROM userreg WHERE id = '$id' ";
                  $result = $conn->query($out);

                  if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                     $name= $row["Name"];
                     $mobile=$row["Numbers"];
                    $adress=$row["Address"];
                     $email= $row["Email"];
                     $password = $row["Password"];

                       // header("Location: user.php");

                }
                } else {
                    echo "0 results";
                }
          ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="style1.css">
    <link rel="icon" href="pro.png">
  </head>
  <body>
    <div class="bodycontain">
      <div class="contain">
        <!-- <h1 style="float:left; padding-left: 20px; color:#535353;">Job Seeker</h1> -->

        <!-- <div class="navbar" style=" width: 100%;">
          <ul>
            <li style="float: right;"><a href="#">Job Seeker</a></li>
            <li style="float: right;"><a href="#">Employer Seeker</a></li>
          </ul>
        </div> -->
      </div>
      <br><br><br><br>
      <form class="loginForm" action="userinsert.php" method="post">
        <h1 style="text-align:center">Edit your Account.</h1> <hr> <br><br>
        <label for="1">Name:</label>
        <input id="1" type="text" name="Name" value="<?php echo $name ?>" required><br>
        <br>
        <label for="6">Contract Number:</label>
        <input id="6" type="text" name="Numbers" value="<?php echo $mobile ?>" required><br>
        <br>
        <label for="4">Address:</label>
        <input id="4" type="text" name="Address" value="<?php echo $adress ?>" required><br>
        <br>
        <label for="3">Email:</label>
        <input id="3" type="email" name="Email" value="<?php echo $email ?>" required><br><br>
        <label for="5">Password:</label>
        <input id="5" type="password" name="Pass" value="<?php echo $password ?>" required><br><br>
        <button type="submit" name="button" value="2">Submit</button>
        <br>
        <br>
        <br>
      </form>
      <br><br><br><br>
    </div>

      <div class="footer">
        &copy;copyright Ruhul Amin.
      </div>

  </body>
</html>
