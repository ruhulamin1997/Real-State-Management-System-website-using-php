<?php
session_start();
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <link rel="stylesheet" href="css\bootstrap.css">
  <link rel="stylesheet" href="css\bootstrap.min.css">
  <link rel="stylesheet" href="js\bootstrap.js">
  <link rel="stylesheet" href="js\bootstrap.min.js">

  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="manu">
    <div class="in_manu">

      <div class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>

          <?php
              if ($_SESSION['userss'] == 1) { ?>
                <li><a href="Profile.php">Profile</a></li>
                <li><a href="reg.html">Sell</a></li>
                <li><a href="logout.php">Logout</a><?php
              }else {
                ?><li><a href="login.html">Login</a>
                <li><a href="userreg.php">Registration</a></li> <?php
              }

            ?>
        </ul>
        <form class="navbar-form navbar-left" action="search.php" method="post">
          <div class="form-group">
            <input type="text" class="form-control" name="search" value="" placeholder="Search">
        </div>
      <button type="submit" class="btn btn-default" value="5">Search</button>
    </form>
      </div>
    </div>
  </div>

  <div class="contan" style="max-width:90%">
      <br><br>
      <div class="headcontain">
        <img src="home.jpg" alt="">
      </div>


    <div class="rightcontan">
      <?php

      $sql = "SELECT  * FROM saleadd ORDER BY id DESC";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {

              $Hous = $row["Hous"];
              $Location = $row["Location"];
              $Flat= $row["Flat"];
              $Discription = $row["Discription"];
              $Price = $row["Price"];
              $_SESSION["Image"] = $row["Image"];
              $_SESSION["productID"] = $row["id"];

              $productID = $_SESSION["productID"];

              ?>
              <div class="jobem">
                <div class="" style="float: left">
                <img src='<?php echo $row["Image"] ?>' alt="" style="width:220px; height: 140px; margin: 5px 20px 5px 0px;">
                </div>

                <h3>House: <?php echo $Hous ?></h3>
                <table>
                  <tr>
                    <th>Location: </th>
                    <td> <?php echo $Location ?></td>
                  </tr>
                  <tr>
                    <th>Flat Size: </th>
                    <td><?php echo   $Flat ?></td>
                  </tr>


                    <tr>
                      <th>Description: </th>
                      <td><?php echo   $Discription ?></td>
                    </tr>
                    <tr>
                      <th>Price:</th>
                      <td><?php echo $Price ?></td>
                    </tr>
                    <!-- <tr>
                      <th>Owner Name:</th>
                      <td><a href="check.php">Details</a><br></td>
                    </tr> -->

                </table>
                <form class="" action="check.php" method="post">
                  <input type="hidden" name="buyid" value="<?php echo $productID ?>">
                  <button type="submit" name="button" style="background: black;">Details</button>
                </form>

              </div>

      <?php
          }
      } else {
          echo "0 results";
      }
      ?>
<br>
      </div>

  </div>

  <footer>
    <br>
    <center>©Copyright 2015 Varendra University.<br>
      Developed by Ruhul Amin, Varendra University. </center>
    <br>
  </footer>
  <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="js/SmoothScroll.js"></script>
  <script type="text/javascript" src="js/nivo-lightbox.js"></script>
  <script type="text/javascript" src="js/jquery.isotope.js"></script>
  <script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
  <script type="text/javascript" src="js/contact_me.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
</body>
</html>
