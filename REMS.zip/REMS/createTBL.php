<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
}

// sql to create table
$sql = "CREATE TABLE saleAdd (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Hous VARCHAR(30) NOT NULL,
Location VARCHAR(30) NOT NULL,
Flat VARCHAR(30) NOT NULL,
Discription VARCHAR(6000) NOT NULL,
Price VARCHAR(30) NOT NULL,
Image VARCHAR(200) NOT NULL
)";
if (mysqli_query($conn, $sql)) {
   echo "Table created successfully";
} else {
   echo "Error creating table: " . mysqli_error($conn);
}

$sql2 = "CREATE TABLE userreg (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Numbers VARCHAR(30) NOT NULL,
Address VARCHAR(30) NOT NULL,
Email VARCHAR(30) NOT NULL,
Password VARCHAR(30) NOT NULL
)";

if (mysqli_query($conn, $sql2)) {
   echo "Table created successfully";
} else {
   echo "Error creating table: " . mysqli_error($conn);
}
$sql2 = "CREATE TABLE transaction (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
buyid VARCHAR(30) NOT NULL,
sellid VARCHAR(30) NOT NULL
)";

if (mysqli_query($conn, $sql2)) {
   echo "Table created successfully";
} else {
   echo "Error creating table: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
