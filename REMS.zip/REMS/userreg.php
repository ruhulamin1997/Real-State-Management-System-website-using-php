<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="style1.css">
    <link rel="icon" href="pro.png">
  </head>
  <body>
    <div class="bodycontain">
      <div class="contain">
        <!-- <h1 style="float:left; padding-left: 20px; color:#535353;">Job Seeker</h1> -->

        <!-- <div class="navbar" style=" width: 100%;">
          <ul>
            <li style="float: right;"><a href="#">Job Seeker</a></li>
            <li style="float: right;"><a href="#">Employer Seeker</a></li>
          </ul>
        </div> -->
      </div>
      <br><br><br><br>
      <form class="loginForm" action="userinsert.php" method="post">
        <h1 style="text-align:center">Create a new Account.</h1> <hr> <br><br>
        <label for="1">Name:</label>
        <input id="1" type="text" name="Name" value="" required><br>
        <br>
        <label for="6">Contact Number:</label>
        <input id="6" type="text" name="Numbers" value="" required><br>
        <br>
        <label for="4">Address:</label>
        <input id="4" type="text" name="Address" value="" required><br>
        <br>
        <label for="3">Email:</label>
        <input id="3" type="email" name="Email" value="" required><br><br>
        <label for="5">Password:</label>
        <input id="5" type="password" name="Pass" value="" required><br><br>
        <button type="submit" name="btn" value="1">Submit</button>
        <br>
        <br>
        <br>
      </form>
      <br><br><br><br><br>
    </div>

      <div class="footer">
        &copy;copyright Ruhul Amin.
      </div>

  </body>
</html>
