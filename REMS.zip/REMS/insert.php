<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}


$Hous = $_POST["Hous"];
$Location = $_POST["Location"];
$Flat = $_POST["Flat"];
$Discription = $_POST["Discription"];
$Price = $_POST["Price"];

$filename = $_FILES["uploadfile"]["name"];
$tempname = $_FILES["uploadfile"]["tmp_name"];

$folder = "images/".$filename;
move_uploaded_file($tempname,$folder);
// echo "<img src='$folder'>";


$sql = "INSERT INTO saleAdd (Hous, Location, Flat, Discription, Price, Image)
VALUES ('$Hous', '$Location', '$Flat', '$Discription', '$Price', '$folder')";

if ($conn->query($sql) === TRUE) {
   echo "New record created successfully";
   header("Location: index.php");
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
