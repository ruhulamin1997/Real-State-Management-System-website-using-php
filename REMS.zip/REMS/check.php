<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}




  if($_SESSION['userss'] == 1){
    echo "show Details";
    $_SESSION["buyid"] = $_POST["buyid"];
    $_SESSION['show'] = 'show_details';

    header("location: details.php");
  }
  elseif ($_POST["login"] == 9) {
    $sql = "SELECT * FROM userreg ORDER BY id DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            // echo "Name: " . $row["Name"]. " - Institute: " . $row["Institute"]. " " . " - Skills: " . $row["Skills"]. " - Experience: " . $row["Experience"]. " " ." - Address: " . $row["Address"]. " " ."<br>";

            if($_POST["user"] == $row["Email"] && $_POST["userpass"] == $row["Password"]){
              $username = $_SESSION['$user'];
              $userpass = $_SESSION['$pass'];
              $_SESSION['Name'] = $row["Name"];
              $_SESSION['userss'] = 1;

              $_SESSION["ID"] = $row["id"];
              echo   $_SESSION["ID"];

              $_SESSION["buyid"] = $_POST["buyid"];

              header("location: index.php");
              break;
            }
          }
      }
      echo "Try Again...";
  }
  else {
    // header("location: userreg.php");
    echo "Try Again...";
    header("location: login.html");
  }

// $conn->close();
?>
