<?php
session_start();
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";

$_SESSION["Image"];
$buyID = $_SESSION["buyid"];
$sellid = $_SESSION["ID"];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

 $btn = $_POST["btn"];
if (isset($btn)==4) {
  $sql = "INSERT INTO transaction (buyid, sellid)
  VALUES ('$buyID', '$sellid')";

  if ($conn->query($sql) === TRUE) {
     echo "New record created successfully";
     header("Location: index.php");
  } else {
     echo "Error: " . $sql . "<br>" . $conn->error;
  }
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <link rel="stylesheet" href="css\bootstrap.css">
  <link rel="stylesheet" href="css\bootstrap.min.css">
  <link rel="stylesheet" href="js\bootstrap.js">
  <link rel="stylesheet" href="js\bootstrap.min.js">

  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="manu">
    <div class="in_manu">

      <div class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="Profile.php">Profile</a></li>
          <!-- <li><a href="#">Buy</a></li> -->
          <li><a href="reg.html">Add</a></li>
          <!-- <li><a href="#Contract">Contract</a></li> -->
          <li><a href="login.html">Login</a>
          <li><a href="userreg.php">Registration</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="contan" style="max-width:90%">
<br><br><br>
      <div class="headcontain">
          <div class="container">
              <div class="row">
                <div class="co">
                  <h2><b><u>Location Information</u> </b> </h2>
                  <h3><b>City:</b> Rajashahi.</h3>
                  <h3><b>Road Numbers:</b> #1, Block A, Niketan.</h3>
                  <h3><b>House Number:</b> #33</h3>
                  <h3><b>Word Numbers:</b> 7</h3>

                  <br>

                  <h2><b><u>Buliding Information</u> </b> </h2>
                  <h3><b>Total of Floor:</b> 15th</h3>
                  <h3><b>Total of Flat:</b> 215</h3>
                  <h3><b>Numbers of Floor:</b> 4th</h3>

                  <br>

                  <h2><b><u>Land Information</u> </b> </h2>
                  <h3><b>Total of Floor:</b> 15th</h3>
                  <h3><b>Total of Flat:</b> 215</h3>
                  <h3><b>Numbers of Floor:</b> 4th</h3>

                  <br>

                  <h2><b><u>Price</u> </b> </h2>
                  <h3><b>Total of Floor:</b> 15th</h3>
                  <h3><b>Total of Flat:</b> 215</h3>
                  <h3><b>Numbers of Floor:</b> 4th</h3>

                </div>
                <br><br>
                <form class="" action="" method="post">
                  <input type="hidden" name="buyid" value="<?php echo $buyID ?>">
                  <center><button type="submit" name="btn" value="4">confirm</button></center>
                </form>
              </div>
          </div>
          <br><br>
      </div>
  </div>

  <footer>
    <br>
    <center>©Copyright 2015 Varendra University.<br>
      Developed by Ruhul Amin, Varendra University. </center>
    <br>
  </footer>
  <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="js/SmoothScroll.js"></script>
  <script type="text/javascript" src="js/nivo-lightbox.js"></script>
  <script type="text/javascript" src="js/jquery.isotope.js"></script>
  <script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
  <script type="text/javascript" src="js/contact_me.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
</body>
</html>
