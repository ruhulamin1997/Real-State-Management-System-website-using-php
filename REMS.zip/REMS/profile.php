



        <?php
        Session_start();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ProjectDB";


        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
           die("Connection failed: " . $conn->connect_error);
        }



            // else if (isset($_POST["save"])) {
            //     $name = $_POST["name"];
            //     $mobile = $_POST["mobile"];
            //     $email = $_POST["email"];
            //     $vu = $_POST["country"];
            //     $pass =$_POST["pass"];
            //
            //     $id = $_SESSION['id'];
            //
            //     $sql = "UPDATE reg SET name='$name', mobile = '$mobile',email = '$email', vu='$vu', pass = '$pass' WHERE id=$id";
            //
            //     if ($conn->query($sql) === TRUE) {
            //       // echo "Record updated successfully";
            //     } else {
            //       echo "Error updating record: " . $conn->error;
            //     }
            //   }
            //
            //   else {
            //         $name = $_SESSION['username'];
            //         $mobile = $_SESSION['mobile'];
            //         $email= $_SESSION['email'];
            //         $vu = $_SESSION['vu'];
            //     }
              $id = $_SESSION["ID"];


                $out = "SELECT * FROM userreg WHERE id = '$id' ";
                  $result = $conn->query($out);

                  if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                     $name= $row["Name"];
                     $mobile=$row["Numbers"];
                    $adress=$row["Address"];
                     $email= $row["Email"];
                     $password = $row["Password"];
                     $_SESSION["ID"] = $row["id"];

                       // header("Location: user.php");

                }
                } else {
                    echo "0 results";
                }
          ?>





<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Home</title>

  <link rel="stylesheet" href="css\bootstrap.css">
  <link rel="stylesheet" href="css\bootstrap.min.css">
  <link rel="stylesheet" href="js\bootstrap.js">
  <link rel="stylesheet" href="js\bootstrap.min.js">

  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

  <link rel="stylesheet" href="style3.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <div class="manu">
    <div class="in_manu">

      <div class="nav">
        <ul>
          <li><a href="index.php">Home</a></li>

          <!-- <li><a href="#">Buy</a></li> -->
          <li><a href="reg.html">Sell</a></li>
          <!-- <li><a href="#Contract">Contract</a></li> -->
          <?php
              if ($_SESSION['userss'] == 1) { ?>
                <li><a href="logout.php">Logout</a><?php
              }else {
                ?><li><a href="login.html">Login</a>
                <li><a href="userreg.php">Registration</a></li> <?php
              }

            ?>
        </ul>
        <form class="navbar-form navbar-left" action="search.php" method="post">
          <div class="form-group">
            <input type="text" class="form-control" name="search" value="" placeholder="Search">
        </div>
      <button type="submit" class="btn btn-default" value="5">Search</button>
    </form>
      </div>
    </div>
  </div>

<br><br>
  <div class="bodycontain">

    <!-- <div class="leftcontain" style="margin: 0 auto; float: none;width: 50%;">
      <div class="procontain">
        <br> -->
<br><br><br><br><br>

        <form class="loginForm" action="proedit.php" method="post" style="width: 30%;">
          <h3>Profile Picture</h3>
          <br>
          <div class="profile_Pic">
            <img src="pro.png" alt="Profile Picture">
          </div>
          <br>
          <br>
        <table>
          <tr>
            <th>Name:</th>
            <td><?php echo $name ?></td>
          </tr>
          <tr>
            <th>Mobile:</th>
            <td><?php echo $mobile ?></td>
          </tr>
          <tr>
            <th>Email:</th>
            <td><?php echo $email ?></td>
          </tr>
          <tr>
            <th>Location:</th>
            <td><?php echo $adress ?>.</td>
          </tr>

        </table>
        <br>

        <p style="text-align:center;"><input type="submit" name="" value="Edit " style=" background: #08443b;"> </p>
          <br>
        </form>

    <br><br><br><br><br><br>
  </div>

  <div class="footer">
    &copy;copyright Ruhul Amin.
  </div>

</body>
</html>
