<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ProjectDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

$Name = $_POST["Name"];
$Numbers = $_POST["Numbers"];
$Address = $_POST["Address"];
$Email = $_POST["Email"];
$Pass = $_POST["Pass"];
$id =$_SESSION["ID"];

if (isset($_POST["btn"])==1) {
  $sql = "INSERT INTO userreg (Name, Numbers, Address, Email, Password)
  VALUES ('$Name', '$Numbers', '$Address', '$Email', '$Pass')";

  if ($conn->query($sql) === TRUE) {
     echo "New record created successfully";
     header("Location: index.php");
  } else {
     echo "Error: " . $sql . "<br>" . $conn->error;
  }
}
elseif (isset($_POST["button"])==2) {
    $sql = "UPDATE userreg SET Name='$Name', Numbers= '$Numbers', Address = '$Address',Email='$Email',Password='$Pass'  WHERE id= '$id'";

  if ($conn->query($sql) === TRUE) {
      echo "Record updated successfully";
      header("Location: profile.php");
  } else {
      echo "Error updating record: " . $conn->error;
  }

}



$conn->close();
?>
