<?php
session_start();
 echo "Development is runing..." ?>
